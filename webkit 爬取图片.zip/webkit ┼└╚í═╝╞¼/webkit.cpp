#include "webkit.h"
#include <QDebug>
#include <QWebSettings>
#include <QWebPage>
#include <QWebFrame>
#include <QWebElementCollection>

#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>

#include <QEventLoop>
#include <QCoreApplication>
#include <QFileInfo>
#include <QTimer>

webkit::webkit(QWidget *parent)
	: QWidget(parent)
	, proxy(QNetworkProxy::Socks5Proxy,"192.168.0.1",1088)
	, m_page(0)
	, m_close(false)
{
	ui.setupUi(this);
//	setAttribute(Qt::WA_DeleteOnClose,true);

	//����
// 	ui.webView->page()->networkAccessManager()->setProxy(proxy);

	//webview����
	QWebSettings * setting=ui.webView->settings();
	setting->setAttribute(QWebSettings::AutoLoadImages,false);
	setting->setAttribute(QWebSettings::JavaEnabled,false);

	connect(ui.webView,&QWebView::loadProgress,this,&webkit::onProgress);
	connect(ui.webView,&QWebView::loadFinished,this,&webkit::onFinished);
}

webkit::~webkit()
{

}

void webkit::on_load_clicked()
{
	QString url=ui.lineEdit->text();
	ui.webView->load(url);
}

void webkit::onProgress(int progress)
{
	this->setWindowTitle(QString::number(progress)+"%");
}

void webkit::onFinished(bool ok)
{
	qDebug()<<QString("load finished " +ok?"success" :"fail");
	QString path=QCoreApplication::applicationDirPath()+'/';

	QWebFrame * pFrame=ui.webView->page()->mainFrame();
	//����
	QWebElementCollection eles=pFrame->findAllElements("body > div.wrap > div > div >div.tupian > p > img");
	foreach(QWebElement ele,eles){
		if(m_close){return;}
		QString url = ele.attribute("src");
		QImage image=downloadImage(url);

		QFileInfo info(url);
		image.save(path+info.fileName());

		//��ʱ
		QEventLoop loop;
		QTimer::singleShot(1000, 
			&loop,
			&QEventLoop::quit);	//5��󣬴���loop.quit
		loop.exec();
	}

	if(m_close){return;}
	//��һҳ
	eles=pFrame->findAllElements("body > div.wrap > div:nth-child(5) > div:nth:child(1) >div.next2 > a.nth-child(2) > img");
	if(eles.count()==0){qDebug()<<++m_page;return;}

	QString nextPage="http://www.qqjay.com"+ eles.at(0).attribute("herf");
	ui.webView->load(QUrl(nextPage));
}


QImage webkit::downloadImage(const QString &url)
{
	QNetworkAccessManager mgr;
	//mgr.setProxy(proxy);

	QNetworkRequest request;
	request.setUrl(QUrl(url));
	QNetworkReply * reply=mgr.get(request);

	QEventLoop loop;
	connect(reply,&QNetworkReply::finished,&loop,&QEventLoop::quit);
	loop.exec();

	QByteArray data=reply->readAll();
	QImage image=QImage::fromData(data);
	return image;
}
