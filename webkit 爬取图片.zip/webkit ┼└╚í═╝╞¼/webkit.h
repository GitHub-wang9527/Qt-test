#ifndef WEBKIT_H
#define WEBKIT_H

#include <QWidget>
#include <QImage>
#include <QNetworkProxy>
#include "ui_webkit.h"


class QNetworkProxy;
class webkit : public QWidget
{
	Q_OBJECT

public:
	webkit(QWidget *parent = 0);
	~webkit();
private slots:
	void on_load_clicked();
	void onProgress(int progress);
	void onFinished(bool ok);
protected:
	void closeEvent(QCloseEvent *e){
		m_close=true;
		return QWidget::closeEvent(e);
	}
private:
	QImage downloadImage(const QString &url);
private:
	Ui::webkitClass ui;
	QNetworkProxy proxy;
	int m_page;
	bool m_close;
};

#endif // WEBKIT_H
